import { useEffect, useState } from 'react';

const Header = () => {
  const [outletName, setOutletName] = useState('');

  useEffect(() => {
    setOutletName(localStorage.getItem('outlet_name'));
  }, []);

  return (
    <header>
      <div className="w-full mx-auto py-6 px-4 ">
        <h1 className="text-3xl font-bold text-gray-900">
          {outletName? outletName: "Nutrizone"}
        </h1>
      </div>
    </header>
  );
};

export default Header;
