
// ResetButton.js
import React from 'react';
import db from '@/lib/db';
import { fetchAndSaveProducts, fetchAndSaveCustomers, fetchAndSaveCategories, fetchAndSaveTaxes, fetchAndSaveData } from '@/lib/dataService';

const ResetButton = ({ setProducts, setProgress, setLoading }) => {
    const handleReset = async () => {
        try {
            setLoading(true); // Begin loading state
          await db.products.clear();
          await db.customers.clear();
          await db.categories.clear();
          await db.taxes.clear();
          // Clear other necessary databases here
          const storedProducts = await db.products.toArray();
          setProducts(storedProducts);
    
          await fetchAndSaveData(setProducts, setProgress, setLoading);
          setLoading(false); // Begin loading state
          alert('Data refreshed from WooCommerce successfully!');
          const storedProducts2 = await db.products.toArray();
          setProducts(storedProducts2);
        } catch (error) {
            setLoading(false); // Begin loading state
          console.error('Error resetting database:', error);
          alert('Failed to reset data, please try again.');
        }
      };

  return (
    <button onClick={handleReset} className="bg-red-500r text-whiter px-2r py-2r rounded mt-4">
      Reset Data
    </button>
  );
};

export default ResetButton;
