import React, { useState } from 'react';
import axios from 'axios';
import config from '@/lib/config';

const Checkout = ({ cartItems, discount, loyaltyPoints, customer, setCartItems, setDiscount, setLoyaltyPoints }) => {

   //     const [total, setTotal] = useState(0);

  const calculateTotal = () => {
    let total = cartItems.reduce((acc, item) => acc + item.price * item.quantity, 0);
    total = total * ((100 - discount) / 100);
    total = total * ((100 - loyaltyPoints) / 100);
    return total.toFixed(2);
  };
  const calculateTotalPrice = () => {
    const totalPrice = cartItems.reduce((sum, item) => sum + Number(item.price) * item.quantity, 0);
    return Math.max(totalPrice - discount, 0).toFixed(2);
  };
  const handleCheckout = async () => {
    const order = {
      customer_id: customer,
      line_items: cartItems.map(item => ({
        product_id: item.id,
        quantity: item.quantity
      })),
      discount_total: discount,
      meta_data: [
        { key: 'loyalty_points', value: loyaltyPoints }
      ]
    };

    try {
        const response = await axios.post(`${config.apiBaseUrl}/orders`, order, {
          auth: config.auth
        });
        alert('Order placed successfully');
        // Logic to reset the cart and other state variables after successful order placement
        // e.g., setCartItems([]);
        setCartItems([]); // Reset cart items
        setDiscount(0); // Reset discount
        setLoyaltyPoints(0); // Reset loyalty points
      } catch (error) {
        console.error('Error placing order:', error);
        alert('Failed to place order, please try again');
      }
    };

  return (
    <div className="bg-white p-4 rounded shadow-lg mt-4">
      <h2 className="text-lg font-bold mb-2">Checkout</h2>
      <div className="mb-4">
        <p>Sub total: ${parseInt(discount)+parseInt(calculateTotalPrice())}</p>
        <p>Discount: ${discount}</p>
        <p>Total: ${calculateTotalPrice()}</p>
      </div>
      <button className="bg-blue-500 text-white px-4 py-2 rounded w-full" onClick={handleCheckout}>
        Place Order
      </button>
    </div>
  );
};

export default Checkout;
