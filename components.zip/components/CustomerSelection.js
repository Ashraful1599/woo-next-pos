import React, { useEffect, useState } from 'react';
import axios from 'axios';
import config from '@/lib/config';

const CustomerSelection = ({ customer, setCustomer }) => {
  const [customers, setCustomers] = useState([]);

  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        const response = await axios.get(`${config.apiBaseUrl}/customers`, {
          auth: config.auth
        });
        setCustomers(response.data);
      } catch (error) {
        console.error('Error fetching customers:', error);
      }
    };
    fetchCustomers();
  }, []);

  return (
    <div className="bg-white p-4 rounded shadow-lg">
      <h2 className="text-lg font-bold mb-2">Customers</h2>
      <select className="border p-2 rounded w-full" onChange={e => setCustomer(e.target.value)}>
        {customers.map(cust => (
          <option key={cust.id} value={cust.id}>
            {cust.first_name} {cust.last_name}
          </option>
        ))}
      </select>
      {customer && (
        <div className="mt-2">
          <p>Selected Customer ID: {customer}</p>
        </div>
      )}
    </div>
  );
};

export default CustomerSelection;

