import React, { useState, useEffect } from 'react';
import axios from 'axios';
import config from '@/lib/config';
import db, { getTaxFromDB } from '@/lib/db';

const Cart = ({ cartItems, setCartItems, placeOrder, clearCart, removeFromCart, setDiscount, discount, customer }) => {
  const [discountAmount, setDiscountAmount] = useState(0);
  const [appliedDiscount, setAppliedDiscount] = useState(0);
  const [loyaltyPoints, setLoyaltyPoints] = useState(0);
  const [taxRates, setTaxRates] = useState([]);
  const [taxAmounts, setTaxAmounts] = useState([]);

  useEffect(() => {
    // Fetch tax rates from the database
    const fetchTaxes = async () => {
      try {
        const taxes = await getTaxFromDB();
        setTaxRates(taxes);
      } catch (error) {
        console.error('Error fetching taxes:', error);
      }
    };

    fetchTaxes();
  }, []);

  useEffect(() => {
    const calculateLoyaltyPoints = (items) => {
      let totalLoyaltyPoints = 0;

      items.forEach(item => {
        const loyaltyCategory = item.categories?.find(category => category.slug === 'loyalty3');

        if (loyaltyCategory) {
          totalLoyaltyPoints += Number(item.price) * 0.03 * item.quantity;
        }
      });

      return totalLoyaltyPoints;
    };

    const points = calculateLoyaltyPoints(cartItems);
    setLoyaltyPoints(points);

  }, [cartItems]);

  const handleApplyDiscount = () => {
    setAppliedDiscount(discountAmount);
    setDiscount(discountAmount);
  };

  const handlePlaceOrder = async () => {
    try {
      const totalPrice = cartItems.reduce((sum, item) => sum + Number(item.price) * item.quantity, 0);
      const discountedTotal = Math.max(totalPrice - appliedDiscount, 0);

      const order = await placeOrder(cartItems, discountedTotal);

      if (loyaltyPoints > 0) {
        await axios.post(`${config.apiBaseUrl}/loyalty`, { points: loyaltyPoints, userId: order.userId });
        setDiscount(loyaltyPoints);
        console.log(`Loyalty points awarded: ${loyaltyPoints}`);
      }

      clearCart();
    } catch (error) {
      console.error('Error placing the order:', error);
    }
  };

  useEffect(() => {
    console.log(cartItems);
  }, [cartItems]);

  const calculateSubTotalPrice = () => {
    return cartItems.reduce((sum, item) => sum + Number(item.price) * item.quantity, 0);
  };

  const calculateTaxAmounts = () => {
    const subTotalPrice = calculateSubTotalPrice();
    const calculatedTaxAmounts = taxRates.map(tax => ({
      ...tax,
      amount: (subTotalPrice * tax.rate / 100).toFixed(2),
    }));
    setTaxAmounts(calculatedTaxAmounts);
  };

  useEffect(() => {
    if (taxRates && taxRates.length > 0) {
      calculateTaxAmounts();
    }
  }, [taxRates, cartItems, discount]);

  const calculateTotalPrice = () => {
    const subTotalPrice = calculateSubTotalPrice();
    const totalTax = taxAmounts.reduce((sum, tax) => sum + parseFloat(tax.amount), 0);
    return (subTotalPrice + totalTax - discount).toFixed(2);
  };

  const handleCheckout = async () => {
    const order = {
      customer_id: customer,
      line_items: cartItems.map(item => ({
        product_id: item.id,
        quantity: item.quantity
      })),
      discount_total: discount,
      meta_data: [
        { key: 'loyalty_points', value: loyaltyPoints }
      ]
    };

    try {
      const response = await axios.post(`${config.apiBaseUrl}/orders`, order, {
        auth: config.auth
      });
      alert('Order placed successfully');
      setCartItems([]);
      setDiscount(0);
      setLoyaltyPoints(0);
    } catch (error) {
      console.error('Error placing order:', error);
      alert('Failed to place order, please try again');
    }
  };

  return (
    <div className="bg-white p-4 rounded shadow-lg col-span-1">
      <h2 className="text-2xl font-bold mb-4">Cart</h2>
      <div>
        {cartItems.map((item) => (
          <li key={`${item.id}-${item.variantOptions || ''}`} className="flex justify-between items-center">
            <div className="flex justify-between items-center">
              <span>
                {item.name} - ${Number(item.price).toFixed(2)} (x{item.quantity})
                {item.variantOptions && (
                  <div className="text-sm text-gray-500">{item.variantOptions}</div>
                )}
              </span>
            </div>
            <button
              className="bg-red-500 text-white px-2 py-1 rounded"
              onClick={() => removeFromCart(item.id, item.variantOptions)}
            >
              Remove
            </button>
          </li>
        ))}
        <div className="mt-4">
          <input
            type="number"
            className="border p-2 rounded w-full"
            placeholder="Enter discount amount"
            value={discountAmount}
            onChange={(e) => setDiscountAmount(Number(e.target.value))}
          />
          <button
            className="bg-blue-500 text-white px-4 py-2 rounded mt-2"
            onClick={handleApplyDiscount}
          >
            Apply Discount
          </button>
        </div>
        <div className="mt-4">
          <span>Discount Applied: ${appliedDiscount.toFixed(2)}</span>
        </div>
        {loyaltyPoints > 0 && (
          <div className="mt-4">
            <span>Loyalty Points Earned: {loyaltyPoints.toFixed(2)}</span>
          </div>
        )}
        <div className="mt-4 border-t pt-4">
          <div className="flex justify-between items-center">
            <span>Sub Total</span>
            <span>${calculateSubTotalPrice().toFixed(2)}</span>
          </div>
          {taxAmounts.map(tax => (
            <div key={tax.id} className="flex justify-between items-center">
              <span>{tax.name}</span>
              <span>${tax.amount}</span>
            </div>
          ))}
          <div className="flex justify-between items-center">
            <span>Discount</span>
            <span>-${discount}</span>
          </div>
          <div className="flex justify-between items-center font-bold">
            <span>Total</span>
            <span>${calculateTotalPrice()}</span>
          </div>
        </div>
      </div>
      <div className="mt-4">
        <button className="w-full py-2 bg-orange-500 text-white rounded-md">Hold Cart</button>
        <button className="w-full py-2 mt-2 bg-green-500 text-white rounded-md">Pay</button>
        <button className="w-full py-2 mt-2 bg-blue-500 text-white rounded-md" onClick={handleCheckout}>
          Place Order
        </button>
      </div>
    </div>
  );
};

export default Cart;
