import React, { useEffect, useState } from 'react';
import axios from 'axios';
import config from '@/lib/config';
import db from '@/lib/db';
import { fetchAndSaveProducts } from '@/lib/dataService';

const ProductList = ({ products, setProducts, addToCart }) => {
//  const [products, setProducts] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [selectedOptions, setSelectedOptions] = useState({});
  const [selectedVariation, setSelectedVariation] = useState(null);

  // useEffect(() => {
  //   const fetchProducts = async () => {
  //     try {
  //       const productIds = [11006, 14593, 14597, 14561, 14573];  // Array of product IDs you want to retrieve
  //       const response = await axios.get(`${config.apiBaseUrl}/products/?include=${productIds.join(',')}`, {
  //         auth: config.auth
  //       });
  //       setProducts(response.data);
  //     } catch (error) {
  //       console.error('Error fetching products:', error);
  //     }
  //   };
  //   fetchProducts();
  // }, []);


  // useEffect(() => {
  //   const fetchProducts = async () => {
  //     const storedProducts = await db.products.toArray();
  //     if (storedProducts.length > 0) {
  //       setProducts(storedProducts);
  //     } else {
  //       // Fetch from WooCommerce as a fallback if not in IndexedDB
  //       await fetchAndSaveProducts();
  //       const newProducts = await db.products.toArray();
  //       setProducts(newProducts);
  //     }
  //   };

  //   fetchProducts();
  // }, []);




  const handleAddToCart = (product) => {
    if (product.type === 'variable') {
      setSelectedProduct(product);
      setSelectedOptions({});
      setSelectedVariation(null);
    } else {
      addToCart(product);
    }
  };


  


  
  const handleOptionChange = (attributeName, optionValue) => {
    const updatedOptions = {
      ...selectedOptions,
      [attributeName]: optionValue,
    };
    setSelectedOptions(updatedOptions);

    const variation = selectedProduct.variations.find(v => 
      v.attributes.every(attr => updatedOptions[attr.name] === attr.option)
    );
    setSelectedVariation(variation);
  };

// // Within ProductList.js or the component handling product selections
// const handleAddVariantToCart = () => {
//     if (selectedVariation) {
//       const variantOptionNames = selectedVariation.attributes
//         ? selectedVariation.attributes.map(attr => `${attr.name}: ${attr.option}`).join(', ')
//         : '';
  
//       addToCart(selectedProduct, selectedVariation, variantOptionNames);
//       setSelectedProduct(null); // Close the popup
//       setSelectedOptions({});
//       setSelectedVariation(null);
//     }
//   };
  
  const handleAddVariantToCart = () => {
    if (selectedVariation) {
      const variantOptionNames = selectedVariation.attributes
        ? selectedVariation.attributes.map(attr => `${attr.name}: ${attr.option}`).join(', ')
        : '';
  
      const variantProduct = {
        ...selectedProduct,
        price: selectedVariation.price,  // Use the price from selected variation
        variantOptions: variantOptionNames
      };
  
      addToCart(variantProduct, selectedVariation, variantOptionNames);
      setSelectedProduct(null); // Close the popup
      setSelectedOptions({});
      setSelectedVariation(null);
    }
  };
  


  
  return (



    
    <div className="bg-white p-4 rounded shadow-lg max-h-full overflow-auto col-span-2">
      <h2 className="text-lg font-bold mb-2">Products</h2>


      
      <ul className="space-y-2 grid grid-cols-3 gap-5">
        {products.map((product, index) => (
          <li data-index={index} key={product.id} className="flex gap-4 flex-col max-h-">
            <span>{product.name} - ${product.price}</span>
            <button className="bg-blue-500 text-white px-2 py-1 rounded" onClick={() => handleAddToCart(product)}>Add to Cart</button>
          </li>
        ))}
      </ul>

      {selectedProduct && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center ">
          <div className="bg-white p-4 rounded shadow-lg">
            <h3 className="text-lg font-bold mb-2">{selectedProduct.name}</h3>
            <div>
              {selectedProduct.attributes.map(attr => (
                <div key={attr.id} className="mb-2">
                  <label className="block text-sm font-semibold mb-1">{attr.name}:</label>
                  <select className="border p-2 rounded w-full" onChange={(e) => handleOptionChange(attr.name, e.target.value)}>
                    <option value="">Select {attr.name}</option>
                    {attr.options.map((option, i) => (
                      <option key={option} value={option}>{option}</option>
                    ))}
                  </select>
                </div>
              ))}
            </div>
            {selectedVariation?.attributes?.length === Object.keys(selectedOptions)?.length && (
              <div className="mt-4">
                <h3 className="text-lg font-bold mb-2">Price: ${selectedVariation.price}</h3>
                <p>{selectedVariation.description}</p>
              </div>
            )}
            <div className="mt-4 flex justify-end">
              <button className="bg-gray-500 text-white px-4 py-2 rounded mr-2" onClick={() => setSelectedProduct(null)}>Cancel</button>
              <button 
                className="bg-blue-500 text-white px-4 py-2 rounded" 
                onClick={handleAddVariantToCart} 
                disabled={!selectedVariation}
              >
                Add to Cart
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProductList;
