// Loading.js
import React from 'react';

const Loading = ({ message, progress }) => (
  <div className="loading">
    <div className="spinner">
      {/* You can replace this with any loading icon or spinner component */}
      <svg width="24" height="24" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" stroke="black" strokeWidth="4" fill="none" strokeDasharray="31.4" strokeLinecap="round" strokeDashoffset="0.1" /></svg>
    </div>
    <p>{message}</p>
    <p>{progress}</p>
    <style jsx>{`
      .loading {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        width: 100%;
        height: 100vh; /* Full height for full-screen loader */
        position: fixed; /* Fixed position */
        top: 0;
        left: 0;
        background: rgba(255, 255, 255, 0.8); /* Light overlay */
        z-index: 9999; /* Ensure it is above everything else */
      }

      .spinner {
        margin-bottom: 10px; /* Space between spinner and text */
        animation: spin 1s linear infinite;
      }

      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
    `}</style>
  </div>
);

export default Loading;
