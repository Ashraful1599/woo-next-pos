'use client'
import CustomerSelection from '@/components/CustomerSelection'
import React from 'react'
import { useEffect, useState } from 'react'
import Header from '@/components/Header'
import Navbar from '@/components/Navbar'

export default function page() {

  const [customer, setCustomer] = useState(null);


  return (


    <div>
      <Header />
      <main>
        <div className="flex">
          {/* <Navbar
            setProducts={setProducts}
            setProgress={setProgress}
            setLoading={setLoading}
          /> */}

          <div className="w-full mx-auto p-4">




{/* start code for each page */}

<CustomerSelection
    customer={customer}
    setCustomer={setCustomer}
  />

{/* end code for each page */}



        </div>
        </div>
      </main>
    </div>

  )
}

