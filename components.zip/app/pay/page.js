"use client";
import ProductList from "@/components/ProductList";
import CustomerSelection from "@/components/CustomerSelection";
import Cart from "@/components/Cart";
import Checkout from "@/components/Checkout";
import axios from "axios";
import React, { useEffect, useState } from "react";
import ResetButton from "@/components/ResetButton";
import db from "@/lib/db";
import {
  fetchAndSaveProducts,
  fetchAndSaveCustomers,
  fetchAndSaveCategories,
  fetchAndSaveTaxes,
  fetchAndSaveData,
} from "@/lib/dataService";
import Loading from "@/components/Loading";
import config from "@/lib/config";
import POSInput from "@/components/POSInput";
import Header from "@/components/Header";
import Navbar from "@/components/Navbar";

export default function Home() {
  const [cartItems, setCartItems] = useState([]);
  const [customer, setCustomer] = useState(null);
  const [discount, setDiscount] = useState(0);
  const [loyaltyPoints, setLoyaltyPoints] = useState(0);
  const [products, setProducts] = useState([]);
  const [progress, setProgress] = useState(0);
  const [loading, setLoading] = useState(false);

  const fetchProductsInBatches = async () => {
    const totalProducts = 70; // Total number of products to fetch
    const batchSize = 20; // Number of products to fetch per batch

    let allProducts = [];
    let page = 1;

    while (allProducts.length < totalProducts) {
      try {
        const response = await axios.get(`${config.apiBaseUrlV1}/products`, {
          params: {
            per_page: batchSize,
            page: page,
          },
          auth: config.auth,
        });

        allProducts = [...allProducts, ...response.data];
        setProducts(allProducts);

        setProgress(Math.min((allProducts.length / totalProducts) * 100, 100));
        page++;
        setLoading(true);
        // Break the loop if there are no more products to fetch
        if (response.data.length === 0) {
          break;
        }
      } catch (error) {
        console.error("Error fetching products:", error);
        break; // Stop the loop on error to avoid infinite calls
      }
    }

    setLoading(false);
  };

  const addToCart = (product, selectedVariation, variantOptions = null) => {
    setCartItems((prevItems) => {
      const itemIndex = prevItems.findIndex(
        (item) =>
          item.id === product.id && item.variantOptions === variantOptions
      );
      if (itemIndex > -1) {
        // Item already exists in the cart
        const updatedItems = [...prevItems];
        updatedItems[itemIndex].quantity += 1;
        return updatedItems;
      } else {
        // New item with variation price
        return [
          ...prevItems,
          {
            ...product,
            price: selectedVariation ? selectedVariation.price : product.price, // Ensure the correct price
            quantity: 1,
            variantOptions: variantOptions,
          },
        ];
      }
    });
  };

  const removeFromCart = (productId, variantOptions) => {
    setCartItems(
      cartItems.filter(
        (item) =>
          !(item.id === productId && item.variantOptions === variantOptions)
      )
    );
  };

  const loadInitialDataFromDB = async () => {
    const storedProducts = await db.products.toArray();
    if (storedProducts.length > 0) {
      setProducts(storedProducts);
    } else {
      // Fetch from WooCommerce as a fallback if not in IndexedDB
      setLoading(true);
      await fetchAndSaveProducts(setProducts, setProgress, setLoading);
      const newProducts = await db.products.toArray();
      setLoading(false);
      setProducts(newProducts);
    }

    const storedCustomers = await db.customers.toArray();
    const storedCategories = await db.categories.toArray();
    // Store loaded data to component's states if necessary
    // similar to ProductList component's strategy
  };

  useEffect(() => {
    loadInitialDataFromDB(); // Load data initially from IndexedDB
  }, []);

  // useEffect(() => {
  //   const initializeData = async () => {
  //     setLoading(true);
  //     await fetchAndSaveData();
  //     setLoading(false);
  //   };

  //   initializeData();
  // }, []);

  const totalAmount = "5"; // You can calculate this dynamically based on the cart

  return (
    <div>
      <Header />
      <main>
        <div className="flex">
          <Navbar
            setProducts={setProducts}
            setProgress={setProgress}
            setLoading={setLoading}
          />

          <div className="w-full mx-auto p-4">


{/* start code for each page */}
<POSInput totalAmount={totalAmount} />
{/* end code for each page */}



        </div>
        </div>
      </main>
    </div>
  );
}
